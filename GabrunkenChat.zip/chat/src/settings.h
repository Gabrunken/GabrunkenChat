#ifndef settings_h_
#define settings_h_
#define MAX_CLIENTS 2
#define MAX_CLIENT_NAME_LENGTH 30
#define MAX_MESSAGE_LENGTH 1000
#endif